CADJ STORE iceMask = tapelev3, key = ilev_3
CADJ STORE iceHeight  = tapelev3, key = ilev_3
CADJ STORE snowHeight = tapelev3, key = ilev_3
CADJ STORE Tsrf    = tapelev3, key = ilev_3
CADJ STORE Qice1   = tapelev3, key = ilev_3
CADJ STORE Qice2   = tapelev3, key = ilev_3
CADJ STORE snowAge = tapelev3, key = ilev_3
CADJ STORE sHeating = tapelev3, key = ilev_3
CADJ STORE flxCndBt = tapelev3, key = ilev_3
CADJ STORE hOceMxL = tapelev3, key = ilev_3

#ifdef ATMOSPHERIC_LOADING
CADJ STORE siceload = tapelev3, key = ilev_3
#endif
