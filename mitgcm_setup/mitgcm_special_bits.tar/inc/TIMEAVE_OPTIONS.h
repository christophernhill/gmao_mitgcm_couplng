C $Header: /u/gcmpack/MITgcm/pkg/timeave/TIMEAVE_OPTIONS.h,v 1.2 2003/10/09 04:19:20 edhill Exp $
C $Name:  $

#ifndef TIMEAVE_OPTIONS_H
#define TIMEAVE_OPTIONS_H
#include "PACKAGES_CONFIG.h"
#ifdef ALLOW_TIMEAVE

#include "CPP_OPTIONS.h"

C CPP macros go here

#endif /* ALLOW_TIMEAVE */
#endif /* TIMEAVE_OPTIONS_H */
