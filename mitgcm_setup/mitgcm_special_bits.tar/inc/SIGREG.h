C $Header: /u/gcmpack/MITgcm/eesupp/inc/SIGREG.h,v 1.1 2005/12/03 08:30:32 edhill Exp $
C $Name:  $

      integer i_got_signal
      common / sig_i / i_got_signal

CEH3 ;;; Local Variables: ***
CEH3 ;;; mode:fortran ***
CEH3 ;;; End: ***

