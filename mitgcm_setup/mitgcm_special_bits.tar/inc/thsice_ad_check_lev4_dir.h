CADJ STORE iceMask = tapelev4, key = ilev_4
CADJ STORE iceHeight  = tapelev4, key = ilev_4
CADJ STORE snowHeight = tapelev4, key = ilev_4
CADJ STORE Tsrf    = tapelev4, key = ilev_4
CADJ STORE Qice1   = tapelev4, key = ilev_4
CADJ STORE Qice2   = tapelev4, key = ilev_4
CADJ STORE snowAge = tapelev4, key = ilev_4
CADJ STORE sHeating = tapelev4, key = ilev_4
CADJ STORE flxCndBt = tapelev4, key = ilev_4
CADJ STORE hOceMxL = tapelev4, key = ilev_4

#ifdef ATMOSPHERIC_LOADING
CADJ STORE siceload = tapelev4, key = ilev_4
#endif
