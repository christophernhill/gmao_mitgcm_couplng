C $Header: /u/gcmpack/MITgcm/pkg/debug/DEBUG_OPTIONS.h,v 1.2 2003/10/09 04:19:19 edhill Exp $
C $Name:  $

#ifndef DEBUG_OPTIONS_H
#define DEBUG_OPTIONS_H
#include "PACKAGES_CONFIG.h"
#ifdef ALLOW_DEBUG

#include "CPP_OPTIONS.h"

C CPP Macros go here

#endif /* ALLOW_DEBUG */
#endif /* DEBUG_OPTIONS_H */
