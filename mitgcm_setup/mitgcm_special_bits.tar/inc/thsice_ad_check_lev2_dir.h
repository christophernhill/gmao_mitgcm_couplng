CADJ STORE iceMask   = tapelev2, key = ilev_2
CADJ STORE iceHeight  = tapelev2, key = ilev_2
CADJ STORE snowHeight = tapelev2, key = ilev_2
CADJ STORE Tsrf     = tapelev2, key = ilev_2
CADJ STORE Qice1    = tapelev2, key = ilev_2
CADJ STORE Qice2    = tapelev2, key = ilev_2
CADJ STORE snowAge  = tapelev2, key = ilev_2
CADJ STORE sHeating = tapelev2, key = ilev_2
CADJ STORE flxCndBt = tapelev2, key = ilev_2
CADJ STORE hOceMxL  = tapelev2, key = ilev_2

#ifdef ATMOSPHERIC_LOADING
CADJ STORE siceload = tapelev2, key = ilev_2
#endif
