C $Header: /u/gcmpack/MITgcm/pkg/mom_fluxform/MOM_FLUXFORM_OPTIONS.h,v 1.2 2003/10/09 04:19:19 edhill Exp $
C $Name:  $

C CPP options file for mom_fluxform package
C
C Use this file for selecting CPP options within the mom_fluxform package

#ifndef MOM_FLUXFORM_OPTIONS_H
#define MOM_FLUXFORM_OPTIONS_H
#include "PACKAGES_CONFIG.h"
#ifdef ALLOW_MOM_FLUXFORM

#include "CPP_OPTIONS.h"

C CPP macros go here

#endif /* ALLOW_MOM_FLUXFORM */
#endif /* MOM_FLUXFORM_OPTIONS_H */
