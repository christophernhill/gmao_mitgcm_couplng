C $Header: /u/gcmpack/MITgcm/model/inc/THE_MODEL_COMMON_BLOCKS.h,v 1.8 2003/10/31 20:35:32 edhill Exp $
C $Name:  $

#include "PARAMS.h"
#include "GRID.h"
#include "DYNVARS.h"
#include "FFIELDS.h"
#include "SURFACE.h"
#ifdef ALLOW_TIMEAVE
#include "TIMEAVE_STATV.h"
#endif
