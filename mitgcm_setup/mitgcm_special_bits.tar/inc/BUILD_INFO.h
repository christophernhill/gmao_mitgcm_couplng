#define THISVER 'checkpoint58u_post'
#define THISUSER 'cnh'
#define THISDATE 'Sat Feb  3 21:12:25 EST 2007'
#define THISHOST 'localhost.localdomain'
