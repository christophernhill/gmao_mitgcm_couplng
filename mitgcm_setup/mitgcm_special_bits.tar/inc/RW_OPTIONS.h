C $Header: /u/gcmpack/MITgcm/pkg/rw/RW_OPTIONS.h,v 1.1 2005/08/22 23:00:58 jmc Exp $
C $Name:  $

C CPP options file for RW package
C
C Use this file for selecting options within the RW package

#ifndef RW_OPTIONS_H
#define RW_OPTIONS_H
#include "PACKAGES_CONFIG.h"
#ifdef ALLOW_RW

#include "CPP_OPTIONS.h"

#endif /* ALLOW_RW */
#endif /* RW_OPTIONS_H */

CEH3 ;;; Local Variables: ***
CEH3 ;;; mode:fortran ***
CEH3 ;;; End: ***
