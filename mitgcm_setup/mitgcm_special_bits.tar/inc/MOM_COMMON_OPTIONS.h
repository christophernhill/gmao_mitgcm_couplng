C $Header: /u/gcmpack/MITgcm/pkg/mom_common/MOM_COMMON_OPTIONS.h,v 1.1 2004/05/14 17:43:11 adcroft Exp $
C $Name:  $

C CPP options file for mom_common package
C
C Use this file for selecting CPP options within the mom_common package

#ifndef MOM_COMMON_OPTIONS_H
#define MOM_COMMON_OPTIONS_H
#include "PACKAGES_CONFIG.h"
#ifdef ALLOW_MOM_COMMON

#include "CPP_OPTIONS.h"

C CPP macros go here

#endif /* ALLOW_MOM_COMMON */
#endif /* MOM_COMMON_OPTIONS_H */
